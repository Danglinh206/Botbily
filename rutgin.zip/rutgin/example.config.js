module.exports = {
    botToken:'<Bot Token Here>',
    bitlyToken:'3e9841c2e0cb971d9cc5d6e87175bb79e1e92719'
};